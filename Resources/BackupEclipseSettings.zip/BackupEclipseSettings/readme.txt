备份符合本人习惯的工作空间配置方便复用

字体等配置
用 .settings 文件夹 替换 workspace/.metadata/.plugins/org.eclipse.core.runtime 中 的 .settings 文件夹

导入代码风格
点击 Window->Preference->C/C++->Formatter->Import，选择 xml 文件
